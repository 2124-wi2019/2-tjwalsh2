/* Tyler Walsh
walsh_ao2b.js
19WI_INFO_2124_WW
Thoendel
12/15/2019 */

let myName = "Tyler Walsh";
var myAge = "20";
const myHair = "Black";
const myEye = "Blue";

console.log();
console.log("My Name:");
console.log(myName);
console.log("My Age:");
console.log(myAge);
console.log("My Hair Color:");
console.log(myHair);
console.log("My Eye Color");
console.log(myEye);
console.log();